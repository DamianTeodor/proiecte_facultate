package managing;

import graphic.Graphics;
import miscellaneous.SortByArrival;
import models.Client;
import models.Server;
import scheduler.Scheduler;

import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Manager implements Runnable
{
    private float averageWaitingTime = 0;
    private int timeLimit;
    private int maxProcessingTime;
    private int minProcessingTime;
    private int maxArrivalTime;
    private int minArrivalTime;
    private int numberOfServers;
    private int numberOfClients;
    private Scheduler scheduler;
    private List<Client> generatedClients = new ArrayList<Client>();
    private FileWriter outputWriter;
    private Graphics input;
    private ArrayList<Float> waitingValues;

    public Manager(Graphics input, FileWriter outputWriter, int timeLimit, int maxProcessingTime, int minProcessingTime, int maxArrivalTime, int minArrivalTime, int numberOfServers, int numberOfClients)
    {
        this.input = input;
        this.outputWriter = outputWriter;
        this.timeLimit = timeLimit;
        this.maxProcessingTime = maxProcessingTime;
        this.minProcessingTime = minProcessingTime;
        this.maxArrivalTime = maxArrivalTime;
        this.minArrivalTime = minArrivalTime;
        this.numberOfServers = numberOfServers;
        this.numberOfClients = numberOfClients;
        this.scheduler = new Scheduler(this.numberOfServers, this.numberOfClients);
        this.waitingValues = new ArrayList<Float>(numberOfClients);
        generateNRandomClients();
    }

    public float averageWaiting()
    {
        waitingValues.toString();
        Float sum = Float.valueOf(0);
        Float numberClients = Float.valueOf(numberOfClients);
        float media;
        for (Float num : waitingValues)
        {
            sum += num;
        }
        media = sum.floatValue() / numberClients.floatValue();
        return media;
    }

    private void generateNRandomClients()
    {
        for(int i = 1; i <= numberOfClients; i++)
        {
            Random r1 = new Random();
            Random r2 = new Random();
            int randomArrivalTime = r1.nextInt(maxArrivalTime - minArrivalTime) + minArrivalTime;
            int randomProcessingTime = r2.nextInt(maxProcessingTime - minProcessingTime) + minProcessingTime;
            generatedClients.add(new Client(i, randomArrivalTime, randomProcessingTime));
        }
        Collections.sort(generatedClients, new SortByArrival());
        printClients();
    }
    public int timeToClose()
    {
        int waitingClients = 0;
        int queueClients = 0;
        if(generatedClients.isEmpty())
        {
            waitingClients = 1;
        }
        for(Server server : scheduler.getServers())
        {
            if(!server.getClients().isEmpty())
            {
                queueClients = 1;
                break;
            }
        }
        if(waitingClients == 1 && queueClients == 0)
        {
            return 0;
        }
        return 1;
    }

    public String printClients()
    {
        String s = "Clients in waiting: ";
        if (generatedClients.isEmpty())
        {
            s += "None";
        }
        else
        {
            for (Client client : generatedClients)
            {
                s += client + ";";
            }
        }
        s += "\n";
        return s;
    }

    public String printServers()
    {
        String s = "";
        int i = 0;
        for(Server server : scheduler.getServers())
        {
            if(!server.getClients().isEmpty())
            {
                int isClosed = 1;
                s += "Queue" + (i + 1) + ":";
                for(Client client : server.getClients())
                {
                    if(client.getServiceTime() != 0)
                    {
                        s += client + ";";
                        isClosed = 0;
                    }
                }
                if(isClosed == 1)
                {
                    s += " closed";
                }
                s += "\n";
            }
            else
            {
                s += "Queue" + (i + 1) + ": " + "closed" + "\n";
            }
            i++;
        }
        s += "\n";
        return s;
    }

    public String printInFile()
    {
        String s = "";
        s = printClients() + printServers();
        return s;
    }

    @Override
    //aici
    public void run()
    {
        System.out.println("Se ruleaza");
        int currentTime = 0;
        while (timeToClose() != 0 && currentTime < timeLimit)
        {
            String s = "";
            while (!generatedClients.isEmpty() && currentTime == generatedClients.get(0).getArrivalTime())
            {
                int i;
                if (scheduler.getServers().isEmpty() == true)
                {
                    i = 0;
                }
                else
                {
                    i = scheduler.getMinServer();
                }
                if (scheduler.getServers().get(i).getClients().isEmpty() == true)
                {
                    Thread tr = new Thread(scheduler.getServers().get(i));
                    waitingValues.add(scheduler.dispatchClient(generatedClients.get(0)));
                    tr.start();
                }
                else
                {
                    waitingValues.add(scheduler.dispatchClient(generatedClients.get(0)));
                }
                generatedClients.remove(generatedClients.get(0));
            }
            try
            {
                Thread.sleep(1000);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
            s = printInFile();
            String s2 = "";
            s2 = "Time " + currentTime + "\n" + s + "\n";
            try
            {
                outputWriter.write("Time " + currentTime + "\n" + s);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            input.setUpdateText(s2);
            currentTime++;
        }
        try
        {

            outputWriter.write("Average Time: " + averageWaiting());
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        try
        {
            outputWriter.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        System.out.println("S-a scris in fisier");
    }
}