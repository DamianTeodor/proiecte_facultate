package models;

import models.Client;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class Server implements Runnable, Comparable<Server>
{
    private BlockingQueue<Client> clients;
    private AtomicInteger waitingPeriod;
    private int number;
    private int numberOfClients;

    public Server(int number, int numberOfClients)
    {
        this.number = number;
        this.numberOfClients = numberOfClients;
        this.waitingPeriod = new AtomicInteger(0);
        this.clients = new ArrayBlockingQueue<Client>(numberOfClients);
    }

    public BlockingQueue<Client> getClients()
    {
        return clients;
    }

    public AtomicInteger getWaitingPeriod()
    {
        return waitingPeriod;
    }

    public void addClient(Client newClient)
    {
        if(clients.remainingCapacity() == 0)
        {
            return;
        }
        clients.add(newClient);
        waitingPeriod.getAndAdd(newClient.getServiceTime());
    }

    public int getNumber()
    {
        return number;
    }

    @Override
    //aici
    public void run()
    {
        boolean clientInQueue;
        boolean notFirstIteration = false;
        Client cl = null;
        while(true)
        {
            clientInQueue = false;
            if(clients.peek() != null)
            {
                cl = clients.peek();
                clientInQueue = true;
            }
            while (clientInQueue)
            {
                try
                {
                    Thread.sleep(900);
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
                if(notFirstIteration)
                {
                    this.waitingPeriod.decrementAndGet();
                    //System.out.println("pentru clientul " + cl.getId() + "avem acuma service inainte " + cl.getServiceTime());
                    cl.setServiceTime(cl.getServiceTime() - 1);
                    //System.out.println("pentru clientul " + cl.getId() + "avem acuma service dupa " + cl.getServiceTime());
                }
                else
                {
                    notFirstIteration = true;
                }
                if(cl.getServiceTime() == 0)
                {
                    this.clients.poll();
                    clientInQueue = false;
                    if(this.waitingPeriod.intValue() == 0)
                    {
                        return;
                    }
                }
            }
        }
    }

    @Override
    public int compareTo(Server o)
    {
        if (this.waitingPeriod.get() > o.getWaitingPeriod().get())
        {
            return 1;
        }
        else if (this.waitingPeriod.get() < o.getWaitingPeriod().get())
        {
            return -1;
        }
        else
        {
            return 0;
        }
    }
}
