package dataAccessLayer;

import model.Order;

public class OrderDAO extends AbstractDAO<Order>
{

}
