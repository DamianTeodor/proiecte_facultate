package dataAccessLayer;
import model.Client;
public class ClientDAO extends AbstractDAO<Client>
{

}
