package dataAccessLayer;

import model.Product;

public class ProductDAO extends AbstractDAO<Product>
{

}
